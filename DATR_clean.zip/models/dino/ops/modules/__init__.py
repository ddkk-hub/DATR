# ------------------------------------------------------------------------------------------------
# Deformable DETR
# Copyright (c) 2020 SenseTime. All Rights Reserved.
# Licensed under the Apache License, Version 2.0 [see LICENSE for details]
# ------------------------------------------------------------------------------------------------
# Modified from https://github.com/chengdazhi/Deformable-Convolution-V2-PyTorch/tree/pytorch_1.0.0
# ------------------------------------------------------------------------------------------------

import os as _os
import site as _site
_cuda_dirs = []
for _sp in _site.getsitepackages():
    _torch_lib = _os.path.join(_sp, 'torch', 'lib')
    if _os.path.exists(_torch_lib):
        _cuda_dirs.append(_torch_lib)
if hasattr(_os, 'add_dll_directory'):
    for _d in _cuda_dirs:
        try:
            _os.add_dll_directory(_d)
        except Exception:
            pass
    import torch as _torch
    if hasattr(_torch, '_cpp_extension_version') and hasattr(_torch._cpp_extension_version, '__file__'):
        _torch_cuda = _os.path.join(_os.path.dirname(_torch.__file__), 'lib')
        if _torch_cuda not in _cuda_dirs and _os.path.exists(_torch_cuda):
            try:
                _os.add_dll_directory(_torch_cuda)
            except Exception:
                pass

from .ms_deform_attn import MSDeformAttn
